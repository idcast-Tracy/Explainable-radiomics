#!/D:/anaconda python
# -*- coding: utf-8 -*-
# @Project : MyScript
# @FileName: FeatureMapByClass.py
# @IDE: PyCharm
# @Time  : 2020/3/9 21:16
# @Author : Jing.Z
# @Email : zhangjingmri@gmail.com
# @Desc : ==============================================
# Life is Short I Use Python!!!                      ===
# ======================================================
import glob
import os
import time
import six

import SimpleITK as sitk
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path

from SKMRradiomics import featureextractor
# from radiomics import featureextractor
from FeatureMapShow import FeatureMapVisualizition


class FeatureMapper:
    """

        This class would found a candidate case image to generate radiomics feature map based voxel. /

    """

    def __init__(self):
        self.feature_pd = pd.DataFrame()
        self.selected_feature_list = []
        self.store_path = ''
        self.kernelRadius = ''
        self.sub_img_array = np.array([])
        self.sub_roi_array = np.array([])

    def load(self, feature_csv_path, selected_feature_list):
        self.feature_pd = pd.read_csv(feature_csv_path, index_col=0)
        self.selected_feature_list = selected_feature_list

    def seek_single_candidate_case(self, feature_name, case_num):
        sub_feature_pd = self.feature_pd[['label', feature_name]].copy()
        sub_feature_pd.sort_values(by=feature_name, inplace=True)
        sorted_index_list = sub_feature_pd.axes[0]
        max_case, min_case = sorted_index_list[-1], sorted_index_list[0]

        max_info = max_case + '(' + str(int(sub_feature_pd.at[max_case, 'label'])) + ')'
        min_info = min_case + '(' + str(int(sub_feature_pd.at[min_case, 'label'])) + ')'
        print('{} value maximum case : {}, minimum case : {}'.format(feature_name, max_info, min_info))
        top_case_list = list(sorted_index_list)[-case_num:]
        last_case_list = list(sorted_index_list)[:case_num]
        return top_case_list, last_case_list

    def seek_candidate_case(self, feature_csv_path, selected_feature_list, case_num):
        """
            seek a candidate image by feature value from feature csv， print the candidate case.

        Parameters
        ----------
        feature_csv_path : str, radiomics feature csv;
        selected_feature_list : list, selected feature name list;


        """
        self.load(feature_csv_path, selected_feature_list)
        candidate_case_list = []
        candidate_case_dict = {}
        for sub_feature in selected_feature_list:
            top_case_list, last_case_list = self.seek_single_candidate_case(sub_feature, case_num)
            candidate_case_dict[sub_feature] = {'top': top_case_list, 'last': last_case_list}

        # seek common case
        for sub_feature in list(candidate_case_dict.keys()):
            all_features = candidate_case_dict[sub_feature]['top'] + candidate_case_dict[sub_feature]['last']
            if len(candidate_case_list) == 0:
                candidate_case_list = all_features

            else:
                candidate_case_list = list(set(candidate_case_list).intersection(set(all_features)))

        # check common case

        for sub_feature in list(candidate_case_dict.keys()):
            sub_checked_case = list(set(candidate_case_dict[sub_feature]['top']).
                                    intersection(set(candidate_case_list)))

            candidate_case_dict[sub_feature]['top'] = [index + "(" + str(int(self.feature_pd.at[index, 'label'])) + ")"
                                                       for index in sub_checked_case]

            sub_checked_case = list(set(candidate_case_dict[sub_feature]['last']).
                                    intersection(set(candidate_case_list)))
            candidate_case_dict[sub_feature]['last'] = [index + "(" + str(int(self.feature_pd.at[index, 'label'])) + ")"
                                                        for index in sub_checked_case]

        df = pd.DataFrame.from_dict(candidate_case_dict, orient='index')

    @staticmethod
    def decode_feature_name(feature_name_list):
        sub_filter_name = ''
        img_setting = {'imageType': 'Original'}
        feature_dict = {}
        for sub_feature in feature_name_list:

            # big feature class
            if sub_feature in ['firstorder', 'glcm', 'glrlm', 'ngtdm', 'glszm']:
                # extract all features
                sub_feature_setting = {sub_feature: []}
                feature_dict.update(sub_feature_setting)

            else:
                img_type = sub_feature.split('_')[-3]
                if img_type.rfind('wavelet') != -1:

                # if img_type in ['LLL', 'HLL','LHL', 'LLH', 'HHL', 'HHH','HLH','LHH']:
                    img_setting['imageType'] = 'Wavelet'
                    sub_filter_name = img_type.split('-')[-1]
                elif img_type.rfind('LOG') != -1:
                    img_setting['imageType'] = 'LoG'
                    sub_filter_name = img_type

                else:
                    img_setting['imageType'] = 'Original'
                # if img_type not in img_setting['imageType']:
                #     img_setting['imageType'].append(img_type)

                feature_class = sub_feature.split('_')[-2]
                feature_name = sub_feature.split('_')[-1]

                if feature_class not in feature_dict.keys():
                    feature_dict[feature_class] = []
                    feature_dict[feature_class].append(feature_name)
                else:
                    feature_dict[feature_class].append(feature_name)
        # print(img_setting)
        # print(feature_dict)
        return img_setting, feature_dict, sub_filter_name

    # crop img by kernelRadius, remove redundancy slice to speed up,
    def crop_img(self, original_roi_path, original_img_path, store_key=''):
        roi = sitk.ReadImage(original_roi_path)
        roi_array = sitk.GetArrayFromImage(roi)

        method = '2D'
        if method == '2D':
            max_roi_slice_index = np.argmax(np.sum(roi_array, axis=(1, 2)))
            z_min, z_max = max_roi_slice_index - self.kernelRadius, max_roi_slice_index + self.kernelRadius + 1

            nonzero_MAX_coords = np.nonzero(roi_array[max_roi_slice_index])
            x_min, x_max = np.min(nonzero_MAX_coords[0]) - self.kernelRadius, np.max(nonzero_MAX_coords[0] + self.kernelRadius + 1)
            y_min, y_max = np.min(nonzero_MAX_coords[1]) - self.kernelRadius, np.max(nonzero_MAX_coords[1] + self.kernelRadius + 1)
            width = int(max(x_max - x_min, y_max - y_min) / 2)
            x_min, x_max = int((x_max + x_min)/2 - width), int((x_max + x_min)/2 + width)
            y_min, y_max = int((y_max + y_min)/2 - width), int((y_max + y_min)/2 + width)
            cropped_roi_array = roi_array[z_min:z_max, x_min:(x_max+1), y_min:(y_max+1)]
            cropped_roi = sitk.GetImageFromArray(cropped_roi_array)

        if method == '3D':
            nonzero_coords = np.nonzero(roi_array)
            z_min, z_max = np.min(nonzero_coords[0]) - self.kernelRadius, np.max(nonzero_coords[0] + self.kernelRadius + 1)
            x_min, x_max = np.min(nonzero_coords[1]) - self.kernelRadius, np.max(nonzero_coords[1] + self.kernelRadius + 1)
            y_min, y_max = np.min(nonzero_coords[2]) - self.kernelRadius, np.max(nonzero_coords[2] + self.kernelRadius + 1)
            width = int(max(x_max - x_min, y_max - y_min) / 2)
            x_min, x_max = int((x_max + x_min)/2 - width), int((x_max + x_min)/2 + width)
            y_min, y_max = int((y_max + y_min)/2 - width), int((y_max + y_min)/2 + width)
            cropped_roi_array = roi_array[z_min:z_max, x_min:(x_max+1), y_min:(y_max+1)]
            cropped_roi = sitk.GetImageFromArray(cropped_roi_array)

        try:
            img = original_img_path
            img_array = sitk.GetArrayFromImage(img)
        except:
            img = sitk.ReadImage(original_img_path)
            img_array = sitk.GetArrayFromImage(img)

        if method == '2D':
            cropped_img_array = img_array[z_min:z_max, x_min:(x_max+1), y_min:(y_max+1)]
            cropped_img = sitk.GetImageFromArray(cropped_img_array)
        if method == '3D':
            cropped_img_array = img_array[z_min:z_max, x_min:(x_max+1), y_min:(y_max+1)]
            cropped_img = sitk.GetImageFromArray(cropped_img_array)


        cropped_roi.SetDirection(roi.GetDirection()); cropped_roi.SetOrigin(roi.GetOrigin()); cropped_roi.SetSpacing(roi.GetSpacing())
        cropped_img.SetDirection(img.GetDirection()); cropped_img.SetOrigin(img.GetOrigin()); cropped_img.SetSpacing(img.GetSpacing())
        roi_info = [roi.GetDirection(), roi.GetOrigin(), roi.GetSpacing()]
        img_info = [img.GetDirection(), img.GetOrigin(), img.GetSpacing()]
        index_dict = {0:'direction', 1:'origin', 2:'spacing'}
        start = 0
        for sub_roi_info, sub_img_info in zip(roi_info, img_info):
            if sub_roi_info != sub_img_info:
                print(index_dict[start], 'failed'); print('roi:', sub_roi_info); print('img:', sub_img_info)

        sitk.WriteImage(cropped_img, os.path.join(self.store_path, store_key + '_cropped_img.nii.gz'))
        sitk.WriteImage(cropped_roi, os.path.join(self.store_path, store_key + '_cropped_roi.nii.gz'))
        self.sub_img_array = np.transpose(cropped_img_array, (1, 2, 0))
        self.sub_roi_array = np.transpose(cropped_roi_array, (1, 2, 0))
        return cropped_img, cropped_roi

    def generate_feature_map(self, candidate_img_path, candidate_roi_path, kernelRadius, features_name_list, store_path):
        """
            Generate specific feature map based on kernel Radius.

        Parameters
        ----------
        candidate_img_path: str, candidate image path;
        candidate_roi_path: str, candidate ROI path;
        kernelRadius: integer, specifies the size of the kernel to use as the radius from the center voxel. \
                    Therefore the actual size is 2 * kernelRadius + 1. E.g. a value of 1 yields a 3x3x3 kernel, \
                    a value of 2 5x5x5, etc. In case of 2D extraction, the generated kernel will also be a 2D shape
                    (original instead of cube).
        feature_name_list: [str], [feature_name1, feature_name2,...] or ['glcm', 'glrlm']
        store_path: str;

        Returns
        -------

        """

        self.kernelRadius = kernelRadius
        self.store_path = store_path
        parameter_path = r'C:\Users\Tracy\Desktop\VV\RadiomicsParams.yaml'
        setting_dict = {'label': 1, 'interpolator': 'sitkBSpline', 'correctMask': True,
                        'geometryTolerance': 10, 'kernelRadius': self.kernelRadius,
                        'maskedKernel': True, 'voxelBatch': 50}

        extractor = featureextractor.RadiomicsFeaturesExtractor(parameter_path, self.store_path, **setting_dict)
        extractor.enableImageTypes(Original={}, Wavelet={}, Gradient ={})
        # extractor.disableAllImageTypes()
        # extractor.disableAllFeatures()

        img_setting, feature_dict, sub_filter_name = self.decode_feature_name(features_name_list)
        extractor.enableImageTypeByName(**img_setting)
        extractor.enableFeaturesByName(**feature_dict)

        cropped_original_img, cropped_original_roi = self.crop_img(candidate_roi_path, candidate_img_path,
                                                                   store_key='original')
        import time
        if sub_filter_name:
            # generate filter image firstly for speeding up
            filter_img_list, featureVector = extractor.execute(candidate_img_path, candidate_roi_path, features_name_list, label=None, voxelBased=False)
            candidate_img_path = os.path.join(self.store_path, sub_filter_name+'.nii.gz')
            if 'wavelet' in candidate_img_path:
                candidate_img_path = os.path.join(os.path.dirname(candidate_img_path), candidate_img_path.split('wavelet.')[-1])
                filter_img = filter_img_list[np.min(filter_img_list.index(sub_filter_name))+1]
            cropped_filter_img, cropped_filter_roi = self.crop_img(candidate_roi_path, filter_img, store_key=sub_filter_name)
            result = extractor.execute(cropped_filter_img, cropped_filter_roi, features_name_list, voxelBased=True)
        else:
            result = extractor.execute(cropped_original_img, cropped_original_roi, features_name_list, voxelBased=True)
        # without parameters, glcm ,kr=5 ,646s ,cropped img, map shape (5, 132, 128)
        # without parameters, glcm ,kr=1 ,386s ,cropped img, map shape (3, 122, 128)

        # without parameters, glcm ,kr=1 ,566s ,without cropped img, map shape (5, 132, 128)

        # extract original image

        for key, val in six.iteritems(result[1]):
            if isinstance(val, sitk.Image):
                key = key.replace('-', '.')
                if key in features_name_list:
                    sitk.WriteImage(val, store_path + '\\' + key + '.nrrd', True)


    def show_feature_map(self, show_img_path, show_roi_path, show_feature_map_path, store_path):
        feature_map_img = sitk.ReadImage(show_feature_map_path)
        feature_map_array = sitk.GetArrayFromImage(feature_map_img)
        feature_map_array.transpose(1, 2, 0)
        feature_map_visualization = FeatureMapVisualizition()
        feature_map_visualization.LoadData(show_img_path, show_roi_path, show_feature_map_path)

        # hsv/jet/gist_rainbow
        feature_map_visualization.Show(color_map='rainbow', store_path=store_path)


def main():
    from tqdm.contrib import tzip
    feature_mapper = FeatureMapper()
    # features_name_list = [
    # #     'original_glcm_InverseVariance', # CET1WI
    # #     # 'wavelet.LHL_gldm_LowGrayLevelEmphasis',
    # #     # 'wavelet.LHL_glrlm_RunEntropy',
    # #     # 'wavelet.LHL_glszm_SmallAreaEmphasis',
    # #     # 'wavelet.LHL_ngtdm_Strength',
    # #     # 'wavelet.LHH_firstorder_Maximum',
    #     'wavelet.LHH_gldm_DependenceEntropy',
    # #     # 'wavelet.HHL_glcm_Imc1',
    # #     # 'wavelet.HHH_firstorder_Minimum',
    # #     # 'wavelet.LLL_firstorder_Mean',
    # #     # 'original_shape_Elongation',  # T2WI
    # #     # 'original_shape_Flatness',
    # #     # 'wavelet.LLH_gldm_DependenceVariance',
    # #     # 'wavelet.LHL_glcm_MCC',
    # #     'wavelet.HLH_glrlm_GrayLevelNonUniformityNormalized',
    #     'wavelet.HHL_glszm_LargeAreaEmphasis',
    # #     'wavelet.HHL_glszm_LargeAreaLowGrayLevelEmphasis',
    #     'wavelet.HHL_glszm_ZoneVariance',
    # #     # 'wavelet.LLL_glcm_Imc1'
    # ]
    features_name_list = [
        # 'wavelet.HHL_glszm_LargeAreaEmphasis', # T2WI
        # 'wavelet.HHL_glszm_ZoneVariance', # T2WI
        # 'wavelet.LHH_gldm_DependenceEntropy', # CET1WI
        'wavelet.LHL_glszm_SmallAreaEmphasis' # CET1WI
    ]
    Dir = r'E:\Project\My_Project_NPC_Prognosis\07.VVV\BreastRADERData'

    Image_suffix = 'image.nii.gz'
    Mask_suffix = 'Merge.nii'

    # ----- 0. Image-Mask 拉取 ---------
    os.chdir(Dir)
    Image_List = sorted(glob.glob('*' + Image_suffix))  # 批量提取后缀文件
    Mask_List = sorted(glob.glob('*' + Mask_suffix))

    for img_path, roi_path in tzip(Image_List, Mask_List):
        os.chdir(Dir); print('img_path:', img_path, 'roi_path', roi_path)
        store_path = Dir + '\\' + img_path.split('.nii.gz')[0]
        if not Path(store_path).exists():
            Path(store_path).mkdir()
        feature_mapper.generate_feature_map(str(img_path), str(roi_path), kernelRadius=1, features_name_list=features_name_list, store_path=str(store_path))

        os.chdir(store_path)
        for feature_name in features_name_list:
            if 'shape' not in feature_name and 'firstorder' not in feature_name:
                feature_mapper.show_feature_map(show_img_path = 'original_cropped_img.nii.gz',
                                                show_roi_path = 'original_cropped_roi.nii.gz',
                                                show_feature_map_path = feature_name + '.nrrd',
                                                store_path = feature_name)


if __name__ == '__main__':
    main()
